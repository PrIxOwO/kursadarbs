<?php

return [
    'en' => [
        'display' => 'English',
        'flag-icon' => 'us',
    ],
    'de' => [
        'display' => 'German',
        'flag-icon' => 'de',
    ],
    'lv' => [
        'display' => 'Latvian',
        'flag-icon' => 'lv',
    ],
    'lt' => [
        'display' => 'Lithuanian',
        'flag-icon' => 'lt',
    ],
];
