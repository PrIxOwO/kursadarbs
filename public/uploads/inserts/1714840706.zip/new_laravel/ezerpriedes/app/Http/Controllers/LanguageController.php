<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session; // Import the Session facade

class LanguageController extends Controller
{
    public function switchLang($lang)
    {
        if (array_key_exists($lang, config('languages'))) {
            session()->put('applocale', $lang); // Use session() helper function
        }

        return redirect()->back();
    }

    public function languageDemo()
    {
        return view('languageDemo');
    }
}
