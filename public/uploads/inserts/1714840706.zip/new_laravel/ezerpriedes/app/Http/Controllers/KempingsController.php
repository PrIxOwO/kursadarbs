<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;
use App\Models\Kemping;

class KempingsController extends Controller
{
    public function KempingPost()
    {
        $kempings = DB::table('kempings')->select('*')->get();
        return view('kempings', ['kempings' => $kempings]);
    }


    public function addKemping(Request $req)
    {
        $kempings = new Kemping();

        // File upload for atels
        if ($req->hasFile('atels')) {
            $file = $req->file('atels');
            $extension = $file->getClientOriginalExtension();
            $filename = time() . '.' . $extension;
            $fileMoved = $file->move('uploads/kempings', $filename);

            if ($fileMoved) {
                $kempings->atels = $filename;
            } else {
                $kempings->atels = null;
                // Handle the error - log or respond accordingly
            }
        } else {
            $kempings->atels = null;
        }

        // Repeat the process for atels2
        if ($req->hasFile('atels2')) {
            $file2 = $req->file('atels2');
            $extension2 = $file2->getClientOriginalExtension();
            $filename2 = time() . '_2.' . $extension2;  // Use a different name for atels2
            $fileMoved2 = $file2->move('uploads/kempings', $filename2);

            if ($fileMoved2) {
                $kempings->atels2 = $filename2;
            } else {
                $kempings->atels2 = null;
                // Handle the error - log or respond accordingly
            }
        } else {
            $kempings->atels2 = null;
        }

        // Repeat the process for atels3
        if ($req->hasFile('atels3')) {
            $file3 = $req->file('atels3');
            $extension3 = $file3->getClientOriginalExtension();
            $filename3 = time() . '_3.' . $extension3;  // Use a different name for atels3
            $fileMoved3 = $file3->move('uploads/kempings', $filename3);

            if ($fileMoved3) {
                $kempings->atels3 = $filename3;
            } else {
                $kempings->atels3 = null;
                // Handle the error - log or respond accordingly
            }
        } else {
            $kempings->atels3 = null;
        }
        if ($req->hasFile('atels4')) {
            $file4 = $req->file('atels4');
            $extension4 = $file4->getClientOriginalExtension();
            $filename4 = time() . '_4.' . $extension4;  // Use a different name for atels4
            $fileMoved4 = $file4->move('uploads/kempings', $filename4);

            if ($fileMoved4) {
                $kempings->atels4 = $filename4;
            } else {
                $kempings->atels4 = null;
                // Handle the error - log or respond accordingly
            }
        } else {
            $kempings->atels4 = null;
        }
        if ($req->hasFile('atels5')) {
            $file5 = $req->file('atels5');
            $extension5 = $file5->getClientOriginalExtension();
            $filename5 = time() . '_5.' . $extension5;  // Use a different name for atels5
            $fileMoved5 = $file5->move('uploads/kempings', $filename5);

            if ($fileMoved5) {
                $kempings->atels5 = $filename5;
            } else {
                $kempings->atels5 = null;
                // Handle the error - log or respond accordingly
            }
        } else {
            $kempings->atels5 = null;
        }
        if ($req->hasFile('atels6')) {
            $file6 = $req->file('atels6');
            $extension6 = $file6->getClientOriginalExtension();
            $filename6 = time() . '_6.' . $extension6;  // Use a different name for atels6
            $fileMoved6 = $file6->move('uploads/kempings', $filename6);

            if ($fileMoved6) {
                $kempings->atels6 = $filename6;
            } else {
                $kempings->atels6 = null;
                // Handle the error - log or respond accordingly
            }
        } else {
            $kempings->atels6 = null;
        }
        if ($req->hasFile('atels7')) {
            $file7 = $req->file('atels7');
            $extension7 = $file7->getClientOriginalExtension();
            $filename7 = time() . '_7.' . $extension7;  // Use a different name for atels7
            $fileMoved7 = $file7->move('uploads/kempings', $filename7);

            if ($fileMoved7) {
                $kempings->atels7 = $filename7;
            } else {
                $kempings->atels7 = null;
                // Handle the error - log or respond accordingly
            }
        } else {
            $kempings->atels7 = null;
        }
        if ($req->hasFile('atels8')) {
            $file8 = $req->file('atels8');
            $extension8 = $file8->getClientOriginalExtension();
            $filename8 = time() . '_8.' . $extension8;  // Use a different name for atels8
            $fileMoved8 = $file8->move('uploads/kempings', $filename8);

            if ($fileMoved8) {
                $kempings->atels8 = $filename8;
            } else {
                $kempings->atels8 = null;
                // Handle the error - log or respond accordingly
            }
        } else {
            $kempings->atels8 = null;
        }
        if ($req->hasFile('atels9')) {
            $file9 = $req->file('atels9');
            $extension9 = $file9->getClientOriginalExtension();
            $filename9 = time() . '_9.' . $extension9;  // Use a different name for atels9
            $fileMoved9 = $file9->move('uploads/kempings', $filename9);

            if ($fileMoved9) {
                $kempings->atels9 = $filename9;
            } else {
                $kempings->atels9 = null;
                // Handle the error - log or respond accordingly
            }
        } else {
            $kempings->atels9 = null;
        }
        if ($req->hasFile('atels10')) {
            $file10 = $req->file('atels10');
            $extension10 = $file10->getClientOriginalExtension();
            $filename10 = time() . '_10.' . $extension10;  // Use a different name for atels10
            $fileMoved10 = $file10->move('uploads/kempings', $filename10);

            if ($fileMoved10) {
                $kempings->atels10 = $filename10;
            } else {
                $kempings->atels10 = null;
                // Handle the error - log or respond accordingly
            }
        } else {
            $kempings->atels10 = null;
        }
        if ($req->hasFile('atels11')) {
            $file11 = $req->file('atels11');
            $extension11 = $file11->getClientOriginalExtension();
            $filename11 = time() . '_11.' . $extension11;  // Use a different name for atels11
            $fileMoved11 = $file11->move('uploads/kempings', $filename11);

            if ($fileMoved11) {
                $kempings->atels11 = $filename11;
            } else {
                $kempings->atels11 = null;
                // Handle the error - log or respond accordingly
            }
        } else {
            $kempings->atels11 = null;
        }
        if ($req->hasFile('atels12')) {
            $file12 = $req->file('atels12');
            $extension12 = $file12->getClientOriginalExtension();
            $filename12 = time() . '_12.' . $extension12;  // Use a different name for atels12
            $fileMoved12 = $file12->move('uploads/kempings', $filename12);

            if ($fileMoved12) {
                $kempings->atels12 = $filename12;
            } else {
                $kempings->atels12 = null;
                // Handle the error - log or respond accordingly
            }
        } else {
            $kempings->atels12 = null;
        }
        if ($req->hasFile('atels13')) {
            $file13 = $req->file('atels13');
            $extension13 = $file13->getClientOriginalExtension();
            $filename13 = time() . '_13.' . $extension13;  // Use a different name for atels13
            $fileMoved13 = $file13->move('uploads/kempings', $filename13);

            if ($fileMoved13) {
                $kempings->atels13 = $filename13;
            } else {
                $kempings->atels13 = null;
                // Handle the error - log or respond accordingly
            }
        } else {
            $kempings->atels13 = null;
        }
        if ($req->hasFile('atels14')) {
            $file14 = $req->file('atels14');
            $extension14 = $file14->getClientOriginalExtension();
            $filename14 = time() . '_14.' . $extension14;  // Use a different name for atels14
            $fileMoved14 = $file14->move('uploads/kempings', $filename14);

            if ($fileMoved14) {
                $kempings->atels14 = $filename14;
            } else {
                $kempings->atels14 = null;
                // Handle the error - log or respond accordingly
            }
        } else {
            $kempings->atels14 = null;
        }
        if ($req->hasFile('atels15')) {
            $file15 = $req->file('atels15');
            $extension15 = $file15->getClientOriginalExtension();
            $filename15 = time() . '_15.' . $extension15;  // Use a different name for atels15
            $fileMoved15 = $file15->move('uploads/kempings', $filename15);

            if ($fileMoved15) {
                $kempings->atels15 = $filename15;
            } else {
                $kempings->atels15 = null;
                // Handle the error - log or respond accordingly
            }
        } else {
            $kempings->atels15 = null;
        }

        // Set other properties
        
        $kempings->price = $req->price;

        $kempings->majas_nosaukums = $req->majas_nosaukums;
        $kempings->issapraksts = $req->issapraksts;
        $kempings->det_apraksts = $req->det_apraksts;


        // Save to the database
        $kempings->save();

        return redirect('kempings');
    }


    public function show($ID)
    {
        $kemping = Kemping::findOrFail($ID);
        return view('kempingsID', ['kempings' => [$kemping]]);
    }
    
    

}
