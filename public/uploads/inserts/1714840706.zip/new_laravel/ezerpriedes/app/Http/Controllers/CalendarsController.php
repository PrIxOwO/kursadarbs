<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Kemping;
use App\Models\Calendar;
use App\Models\Home;

class CalendarsController extends Controller
{
    // Example Controller method
// Example Controller method


public function showRezerv($id)
{
    // Fetch the kemping from the database using the id
    $kemping = Kemping::find($id);

    // Check if a kemping with the given id exists
    if (!$kemping) {
        // You can return a 404 error page or redirect to a different page
        abort(404, 'Kemping not found');
    }

    // Retrieve selected dates here (you can fetch them from your database or any other source)
    // For demonstration, let's assume you fetch them from the database related to the kemping
    $selectedDates = []; // Fetch from database using $kemping->id or any other identifier

    // Pass the kemping and selected dates to the view
    return view('rezerv', ['kemping' => $kemping, 'selectedDates' => $selectedDates]);
}



public function show($kempingsID)
{
    // Retrieve the specific Kempings record based on $kempingsID
    $kempings = Kemping::find($kempingsID);

    if (!$kempings) {
        // Handle the case where the Kempings record is not found
        abort(404);
    }

    $bookedDates = Calendar::where('kempings_id', $kempingsID)
        ->select('date', 'max', 'mid')
        ->get()
        ->toArray();

    // Format the dates to match the JavaScript format
    $bookedDates = array_map(function ($booking) {
        return [
            'date' => date('d/m/Y', strtotime($booking['date'])),
            'max_booking' => $booking['max'],
            'mid_booking' => $booking['mid'],
        ];
    }, $bookedDates);

    return view('kempingsID', compact('kempings', 'bookedDates'));
}




public function edit($kempings_id)
{
    

    $bookedDates = Calendar::where('kempings_id', $kempings_id)->get();

    return view('edditkalendars', ['kempings_id' => $kempings_id, 'bookedDates' => $bookedDates]);

    $calendar = Calendar::where('kempings_id', $kempings_id)->first();
    return view('edditkalendars', ['kempings_id' => $kempings_id]);
    
}





public function update(Request $request, $kempings_id)
{
    if ($request->has('new_record')) {
        $calendar = new Calendar;
    } else {
        $calendar = Calendar::where('kempings_id', $kempings_id)
                            ->where('date', $request->input('date'))
                            ->first();

        if ($calendar === null) {
            $calendar = new Calendar;
            $calendar->kempings_id = $kempings_id;
        }
    }


    $calendar->date = $request->input('date');
    $calendar->max = $request->input('max');
    $calendar->mid = $request->input('mid');
    $calendar->low = $request->input('low');

    $calendar->save();

    return redirect()->route('calendar.show', ['id' => $calendar->id]);
}
}