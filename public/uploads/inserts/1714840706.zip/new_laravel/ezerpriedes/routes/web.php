<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\KempingsController;
use App\Http\Controllers\CalendarsController;
use App\Http\Controllers\CustomAuthController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

/*
Route::get('/kempings', function () {
    return view('kempings');
});
*/

Route::get('/kempings', [KempingsController::class, 'KempingPost']);

Route::post('/addhome', [KempingsController::class, 'addKemping']);
Route::get('/addhome', function () {
    return view('addKempings');
});
Route::get('/kempings/{ID}', [KempingsController::class, 'show']);
Route::get('/kempings/{ID}', [KempingsController::class, 'show'])->name('kempingsID.index');



Route::get('/makskerniekiem', function () {
    return view('makskerniekiem');
});


Route::get('/nosvinet', function () {
    return view('nosvinet');
});
// web.php

Route::get('/kempings/{ID}', [CalendarsController::class, 'show']);




Route::get('/kempings/{kempings_id}/edit', [CalendarsController::class, 'edit'])->name('calendar.edit');
Route::put('/kempings/{kempings_id}', [CalendarsController::class, 'update'])->name('calendar.update');
Route::get('/calendars/{id}', [CalendarsController::class, 'show'])->name('calendar.show');

Route::get('/kempings/{id}/rezerv', [CalendarsController::class, 'showRezerv'])->name('calendar.show');

// login stuff
Route::get('dashboard', [CustomAuthController::class, 'dashboard']); 
Route::get('login', [CustomAuthController::class, 'index'])->name('login');
Route::post('custom-login', [CustomAuthController::class, 'customLogin'])->name('login.custom'); 
Route::get('registration', [CustomAuthController::class, 'registration'])->name('register-user');
Route::post('custom-registration', [CustomAuthController::class, 'customRegistration'])->name('register.custom'); 
Route::get('signout', [CustomAuthController::class, 'signOut'])->name('signout');



Route::get('lang/{lang}', ['as' => 'lang.switch', 'uses' => 'App\Http\Controllers\LanguageController@switchLang']);
Route::get('languageDemo', ['as' => 'languageDemo', 'uses' => 'App\Http\Controllers\LanguageController@languageDemo']);

