   // Function to scroll cards
   function scrollCards(direction) {
    const container = document.querySelector('.scrollcards');
    const scrollAmount = 320 * direction; // Adjust the scroll amount based on your card width
    container.scrollBy({
        top: 0,
        left: scrollAmount,
        behavior: 'smooth'
    });
}

// Touch swipe functionality
let xDown = null;

function handleTouchStart(evt) {
    xDown = evt.touches[0].clientX;
}

function handleTouchMove(evt) {
    if (!xDown) {
        return;
    }

    const xUp = evt.touches[0].clientX;
    const xDiff = xDown - xUp;

    // Determine swipe direction and scroll cards accordingly
    if (xDiff > 0) {
        // Swipe left, scroll right
        scrollCards(1);
    } else {
        // Swipe right, scroll left
        scrollCards(-1);
    }

    // Reset value
    xDown = null;
}

const container = document.querySelector('.scrollcards-container');
container.addEventListener('touchstart', handleTouchStart, false);
container.addEventListener('touchmove', handleTouchMove, false);








var swiper = new Swiper('.swiper', {
    slidesPerView: 'auto',
    // centeredSlides: true,
    // centeredSlidesBounds: true,
    freeMode: true,
    spaceBetween: 30,
    centerInsufficientSlides: true,
    // centeredSlides: true,
    // pagination: {
    //     el: '.swiper-pagination',
    //     clickable: true,
    // },
    scrollbar: {
        el: '.swiper-scrollbar',
        draggable: true,
        dragSize: 22.4,
        snapOnRelease: false,
    },
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
});








const calendarContainer = document.querySelector(".calendar");
const dateHeader = calendarContainer.querySelector(".date h1");
const daysContainer = calendarContainer.querySelector(".days");

const monthNames = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

const today = new Date();
let currentYear = today.getFullYear();
let currentMonth = today.getMonth();

function renderCalendar(year, month) {
  dateHeader.textContent = `${monthNames[month]} ${year}`;

  daysContainer.innerHTML = "";

  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);

  for (let i = 1; i <= lastDay.getDate(); i++) {
    const dayCell = document.createElement("div");
    dayCell.textContent = i;
    daysContainer.appendChild(dayCell);
  }
}

function updateCalendar() {
  renderCalendar(currentYear, currentMonth);
}

function updateMonth(step) {
  currentMonth += step;

  if (currentMonth < 0) {
    currentMonth = 11;
    currentYear--;
  } else if (currentMonth > 11) {
    currentMonth = 0;
    currentYear++;
  }

  updateCalendar();
}

calendarContainer.querySelector(".prev").addEventListener("click", () => {
  updateMonth(-1);
});

calendarContainer.querySelector(".next").addEventListener("click", () => {
  updateMonth(1);
});

updateCalendar();
