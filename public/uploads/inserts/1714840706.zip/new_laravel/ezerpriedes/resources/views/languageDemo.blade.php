@extends ('layouts.app')

@section('content')
    <h1>{{ __('languageDemo.welcome') }}</h1>
    <p>{{ __('languageDemo.introduction') }}</p>
@endsection