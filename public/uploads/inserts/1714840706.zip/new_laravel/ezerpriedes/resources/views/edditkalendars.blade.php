<!DOCTYPE html>
<html>
<head>
    <title>Edit Calendar</title>
</head>
<body>
    <h1>Edit Calendar</h1>
    <form action="{{ route('calendar.update', ['kempings_id' => $kempings_id]) }}" method="POST">
    @csrf
    @method('PUT')
    <h2>Booked Dates</h2>

<ul>
@foreach ($bookedDates as $date)
    <li>
        Date: {{ $date->date }}<br>
        Max: {{ $date->max }}<br>
        Mid: {{ $date->mid }}<br>
        Low: {{ $date->low }}<br>
        ID: {{ $date->id }}
    </li>
@endforeach
</ul>

        <label for="new_record">Create new record:</label><br>
        <input type="checkbox" id="new_record" name="new_record"><br>
        <label for="date">Date:</label><br>
        <input type="date" id="date" name="date"><br>
        <label for="max">Max:</label><br>
        <input type="number" id="max" name="max"><br>
        <label for="mid">Mid:</label><br>
        <input type="number" id="mid" name="mid"><br>
        <label for="low">Low:</label><br>
        <input type="number" id="low" name="low"><br>

        <label for="id">ID:</label><br>
        <input type="text" name="id"><br>


        <label for="kempings_id">Kempings ID:</label><br>
        <input type="text" id="kempings_id" name="kempings_id" value="{{ $kempings_id }}">
        <input type="submit" value="Submit">
    </form>
</body>
</html>