<html>

<head>
    <meta charset="UTF-8">
    <title>Ezerpriedes</title>
    <!-- Add the Bootstrap CSS link here -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <!-- Add the Font Awesome link here -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/heder.css">
    

</head>

<body>



<div class="header">
        <div class="positionHederMain">
            <div class="container-fluid d-flex align-items-center justify-content-between">

                <!-- Move NOSVINĒT to the left side -->
                <div class="header-text">
                    <a href="/" class="homePageFont thisPageID">EZERPRIEDES</a>
                    <a href="/kempings">{{ __('messages.kempings') }}</a>
                    <a href="/nosvinet">{{ __('messages.nosvinet') }}</a>

                    <a href="/makskerniekiem">{{ __('messages.makskernieki') }}</a>

                </div>

                <div class="d-flex">
                    <a href="#" id="kontakti-link">{{ __('messages.kontakti') }}</a>
                    <div class="dropdown dropdownMenuMarginNavBar">
                        <div class="dropdown">
                            <button class="dropbtn">
                                <div class="language-button">
                                    <div class="d-flex align-items-center justify-content-center">
                                        <div class="ml-4">
                                            <img src="photos/{{ app()->getLocale() }}-flag.png" alt="{{ app()->getLocale() }}" class="langImg worldMarginIcon">
                                        </div>
                                        <div class="mr-2 alineFlagToName">

                                            @foreach(config('languages') as $lang => $details)
                                            @if($lang == app()->getLocale())
                                            {{ $details['display'] }}
                                            @endif
                                            @endforeach
                                        </div>
                                        <div>
                                            <img src="photos/down-arrow.png" alt="headerPhoto" class="langImg">
                                        </div>
                                    </div>
                                </div>
                            </button>
                            <div id="myDropdown" class="dropdown-content">
                                @foreach(config('languages') as $lang => $details)
                                @if($lang != app()->getLocale())
                                <a href="{{ route('lang.switch', $lang) }}">
                                    <img src="photos/{{ $lang }}-flag.png" alt="{{ $lang }}" class="langImg">
                                    {{ $details['display'] }}
                                </a>
                                @endif
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>


                <div class="burger-button">
                    <i class="fas fa-bars"></i>
                </div>
            </div>
        </div>
    </div>






    <div class="popup" id="popup1">
        <div class="popupuBorderIner">
            <div class="d-flex justify-content-start">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone phoneAligne" viewBox="0 0 16 16">
                    <path d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.6 17.6 0 0 0 4.168 6.608 17.6 17.6 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.68.68 0 0 0-.58-.122l-2.19.547a1.75 1.75 0 0 1-1.657-.459L5.482 8.062a1.75 1.75 0 0 1-.46-1.657l.548-2.19a.68.68 0 0 0-.122-.58zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.68.68 0 0 0 .178.643l2.457 2.457a.68.68 0 0 0 .644.178l2.189-.547a1.75 1.75 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.6 18.6 0 0 1-7.01-4.42 18.6 18.6 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877z" />
                </svg>
                <p> +371 29461455</p>
            </div>
            <div class="d-flex justify-content-start">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope phoneAligne" viewBox="0 0 16 16">
                    <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z" />
                </svg>
                <p> info@ezerpriedes.lv</p>
            </div>
        </div>
        <a href="#" onclick="hide('popup1')">Ok!</a>
    </div>



    



    <div class="main">

        <div class="galery mb-5">

            <div class="galery-header d-flex justify-content-between align-items-center">
                <div>
                    <b class="bigLeters">Galerija</b>
                </div>

                <div>
                    <!-- Buttons for card navigation -->
                    <button class="galeryButton m-3" onclick="scrollCards(-1)">&#60;</button>
                    <button class="galeryButton" onclick="scrollCards(1)">&#62;</i></button>
                </div>
            </div>


            <section>
                <div class="container-fluid">
                    <div class="scrollcards-container swipeable">
                        <div class="scrollcards">
                            <!-- Your cards go here -->
                            <div class="card">
                                <img class="card-img-top" src="photos/h1.jpg">
                            </div>

                            <div class="card">
                                <img class="card-img-top" src="photos/h2.jpg">
                            </div>

                            <div class="card">
                                <img class="card-img-top" src="photos/h3.jpg">
                            </div>

                            <div class="card">
                                <img class="card-img-top" src="photos/h4.jpg">
                            </div>

                            <div class="card">
                                <img class="card-img-top" src="photos/h5.jpg">
                            </div>

                            <div class="card">
                                <img class="card-img-top" src="photos/h6.jpg">
                            </div>

                            <!-- Add more cards here -->
                        </div>
                    </div>
                </div>
            </section>


            <div class="mt-5">
                <b class="bigLeters pt-1">Apraksts</b>
                <div class="underlineNosvinet mt-2"></div>
                <p class="mt-3">
                    Viesību – banketu zāle līdz 50 personām ar lielisku skatu uz Burtnieka ezeru, Jūsu svinībām, kāzām, darba kolektīvu vai draugu, ģimenes ballītēm.   
                </p>
                <p><b>Cena: 30 EUR stunda / 300 EUR pasākums 24 h (banketu zāles īre bez galdautiem, traukiem, palīgtelpām) / Trauku īre 2,00 Eur personai / Galdautu  īre  3,00 Eur 1 gab. / Palīgtelpu, virtuves īre 50,00 Eur</b> </p>
                <p><b>KĀZĀM: </b>Kempinga „Ezerpriedes” personāls parūpēsies, lai Jūsu kāzu diena izdotos burvīga un neaizmirstama. Piedāvājam Jums šo īpašo dienu nosvinēt viesību zālē, kas atrodas Burtnieka ezera stāvkrastā ar neatkārtojamu skatu uz ezeru un savu pirmo valsi griezt saulrietā.</p>
                <b>Svinību zāles īre kāzām 500,00 EUR (galdautu un trauku noma iekļauta cenā) Kāzu galdi pēc iepriekšēja pasūtījuma.</b>
            </div>




            </div>
    </div>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <h3>Contact Us</h3>
                    <p>Email: contact@example.com</p>
                    <p>Phone: +1 (123) 456-7890</p>
                </div>
                <div class="col-md-5">
                    <h3>Follow Us</h3>
                    <div class="social-icons">
                        <!-- Add social media icons or links here -->
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-md-2">
                    <b>© Copyright 2023</b>
                </div>
            </div>
        </div>
    </footer>

    <script src="js/index.js"></script>
    <script src="index.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha256-SkW4XZBjG0rTY3ngdW3Ed4NxqmGXvACb43G+a+ARrVo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MC9zTCdW04XsK3Tx2Xt5f6KG4sI72GY9n0BzmXnP2X2PeM/MAaHMN7FCfDIlvvn"
        crossorigin="anonymous"></script>


</body>

</html>