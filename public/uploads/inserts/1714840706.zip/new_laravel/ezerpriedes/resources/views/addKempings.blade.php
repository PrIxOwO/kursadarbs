<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mājiņu apraksts</title>
    <!-- Include Bootstrap CSS (adjust the path based on your project structure) -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        form {
            max-width: 500px;
            margin: auto;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
        }

        /* Custom button color */
        .btn-custom {
            background-color: #f9a346;
            border-color: #f9a346;
        }

        .btn-custom:hover {
            background-color: #e0873c;
            border-color: #e0873c;
        }
    </style>
</head>


<body>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h1>Mājiņu apraksts 1</h1>
                <form action="addhome" method="POST" enctype="multipart/form-data">
                    
        @csrf
        <div class="form-group">
            <label for="atels">Atēls</label>
            <input type="file" class="form-control" id="atels" name="atels">
        </div>
        <div class="form-group">
            <label for="majas_nosaukums">Nosaukums</label>
            <input type="text" class="form-control" id="majas_nosaukums" name="majas_nosaukums" placeholder="Nosaukums">
        </div>
        <div class="form-group">
            <label for="issapraksts">Apraksts</label>
            <input type="text" class="form-control" id="issapraksts" name="issapraksts" placeholder="Apraksts">
        </div>

        <p>------------------------------------------------------------------------</p>
        <p>------------------------------------------------------------------------</p>

        <div class="form-group">
            <label for="price">Mājiņas cena</label>
            <input type="text" class="form-control" id="price" name="price" placeholder="Nosaukums">
        </div>


        <div class="form-group">
            <label for="atels2">Atēls</label>
            <input type="file" class="form-control" id="atels2" name="atels2">
        </div>
        <div class="form-group">
            <label for="atels3">Atēls</label>
            <input type="file" class="form-control" id="atels3" name="atels3">
        </div>
        <div class="form-group">
            <label for="atels4">Atēls</label>
            <input type="file" class="form-control" id="atels4" name="atels4">
        </div>
        <div class="form-group">
            <label for="atels5">Atēls</label>
            <input type="file" class="form-control" id="atels5" name="atels5">
        </div>
        <div class="form-group">
            <label for="atels6">Atēls</label>
            <input type="file" class="form-control" id="atels6" name="atels6">
        </div>
        <div class="form-group">
            <label for="atels7">Atēls</label>
            <input type="file" class="form-control" id="atels7" name="atels7">
        </div>
        <div class="form-group">
            <label for="atels8">Atēls</label>
            <input type="file" class="form-control" id="atels8" name="atels8">
        </div>
        <div class="form-group">
            <label for="atels9">Atēls</label>
            <input type="file" class="form-control" id="atels9" name="atels9">
        </div>
        <div class="form-group">
            <label for="atels10">Atēls</label>
            <input type="file" class="form-control" id="atels10" name="atels10">
        </div>
        <div class="form-group">
            <label for="atels11">Atēls</label>
            <input type="file" class="form-control" id="atels11" name="atels11">
        </div>
        <div class="form-group">
            <label for="atels12">Atēls</label>
            <input type="file" class="form-control" id="atels12" name="atels12">
        </div>
        <div class="form-group">
            <label for="atels13">Atēls</label>
            <input type="file" class="form-control" id="atels13" name="atels13">
        </div>
        <div class="form-group">
            <label for="atels14">Atēls</label>
            <input type="file" class="form-control" id="atels14" name="atels14">
        </div>
        <div class="form-group">
            <label for="atels15">Atēls</label>
            <input type="file" class="form-control" id="atels15" name="atels15">
        </div>


        <p>------------------------------------------------------------------------</p>
        <p>------------------------------------------------------------------------</p>

        <div class="form-group">
            <label for="det_apraksts">Detalizēts apraksts</label>
            <input type="text" class="form-control" id="det_apraksts" name="det_apraksts" placeholder="Nosaukums">
        </div>

        <button type="submit" class="btn btn-custom">Submit</button>
        </form>
            </div>
            <div class="col-md-6">
                <h1>Mājiņu apraksts 2</h1>
                <form action="addhome" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="personuSkaits">personu Skaits</label>
                        <input type="text" class="form-control" id="personuSkaits" name="personuSkaits" placeholder="personuSkaits">
                    </div>
                    <div class="form-group">
                        <label for="cenaPersonam1">cena</label>
                        <input type="text" class="form-control" id="cenaPersonam1" name="cenaPersonam1" placeholder="cenaPersonam1">
                    </div>

                    <div class="form-group">
                        <label for="personuSkaits2">personu Skaits 2</label>
                        <input type="text" class="form-control" id="personuSkaits2" name="personuSkaits2" placeholder="personuSkaits2">
                        <div class="form-group">
                        <label for="cenaPersonam2">cena</label>
                        <input type="text" class="form-control" id="cenaPersonam2" name="cenaPersonam2" placeholder="cenaPersonam2">
                    </div>

                    </div>
                    <div class="form-group">
                        <label for="personuSkaits3">personu Skaits 3</label>
                        <input type="text" class="form-control" id="personuSkaits3" name="personuSkaits3" placeholder="personuSkaits3">
                    </div>
                    <div class="form-group">
                        <label for="cenaPersonam4">cena</label>
                        <input type="text" class="form-control" id="cenaPersonam4" name="cenaPersonam4" placeholder="cenaPersonam4">
                    </div>

                    <div class="form-group">
                        <label for="personuSkaits4">personu Skaits 4</label>
                        <input type="text" class="form-control" id="personuSkaits4" name="personuSkaits4" placeholder="personuSkaits4">
                    </div>
                    <div class="form-group">
                        <label for="cenaPersonam5">cena</label>
                        <input type="text" class="form-control" id="cenaPersonam5" name="cenaPersonam5" placeholder="cenaPersonam5">
                    </div>

                    <div class="form-group">
                        <label for="personuSkaits5">personu Skaits 5</label>
                        <input type="text" class="form-control" id="personuSkaits5" name="personuSkaits5" placeholder="personuSkaits5">
                    </div>
                    <div class="form-group">
                        <label for="cenaPersonam6">cena</label>
                        <input type="text" class="form-control" id="cenaPersonam6" name="cenaPersonam6" placeholder="cenaPersonam6">
                    </div>

                </form>
            </div>
        </div>
    </div>

</body>

    <!-- Include Bootstrap JS (if needed) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Include jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>

<script>
    $(document).ready(function () {
        // Hide all additional file inputs and their associated form-group divs initially
        $('[id^=atels]').not('#atels, #atels2').hide();
        $('[id^=atels]').not('#atels, #atels2').closest('.form-group').hide();

        // Show the next file input and its associated form-group div when a photo is added to the previous field
        $('[id^=atels]').change(function () {
            var currentId = $(this).attr('id');
            var nextId = getNextId(currentId);

            // Show the next file input and its associated form-group div
            $('#' + nextId).show().closest('.form-group').show();
        });

        // Function to get the next file input id
        function getNextId(currentId) {
            var currentNumber = parseInt(currentId.match(/\d+/)[0]);
            var nextNumber = currentNumber + 1;
            return currentId.replace(/\d+/, nextNumber);
        }
    });
</script>


</html>