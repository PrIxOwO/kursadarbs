<!DOCTYPE html>

<html lang="en">


<head>
    <meta charset="UTF-8">
    <title>Ezerpriedes</title>
    <!-- Add the Bootstrap CSS link here -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <!-- Add the Font Awesome link here -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="{{ asset('css/heder.css') }}">
    <link rel="stylesheet" href="{{ asset('css/kenpings.css') }}">
    <link rel="stylesheet" href="{{ asset('css/calendar.css') }}">
    <link rel="stylesheet" href="{{ asset('css/homes.css') }}">
    <link rel="stylesheet" href="css/heder.css">
    <style>
.selected {
    background-color: red !important; /* Change this to your desired background color */
}

*{
    text-decoration: none !important ;
}
    </style>



</head>

<body>





<div class="header">
        <div class="positionHederMain">
            <div class="container-fluid d-flex align-items-center justify-content-between">

                <!-- Move NOSVINĒT to the left side -->
                <div class="header-text">
                    <a href="/" class="homePageFont thisPageID">EZERPRIEDES</a>
                    <a href="/kempings">{{ __('messages.kempings') }}</a>
                    <a href="/nosvinet">{{ __('messages.nosvinet') }}</a>

                    <a href="/makskerniekiem">{{ __('messages.makskernieki') }}</a>

                </div>

                <div class="d-flex">
                    
                    <div class="dropdown dropdownMenuMarginNavBar">
                        <div class="dropdown">
                            <button class="dropbtn">
                                <div class="language-button">
                                    <div class="d-flex align-items-center justify-content-center">
                                        <div class="ml-4">
                                            <img src="{{ asset('photos/' . app()->getLocale() . '-flag.png') }}" alt="{{ app()->getLocale() }}" class="langImg worldMarginIcon">

                                        </div>
                                        <div class="mr-2 alineFlagToName">

                                            @foreach(config('languages') as $lang => $details)
                                            @if($lang == app()->getLocale())
                                            {{ $details['display'] }}
                                            @endif
                                            @endforeach
                                        </div>
                                        <div>
                                            <img src="{{ asset('photos/down-arrow.png') }}" alt="headerPhoto" class="langImg">

                                        </div>
                                    </div>
                                </div>
                            </button>
                            <div id="myDropdown" class="dropdown-content">
                                @foreach(config('languages') as $lang => $details)
                                @if($lang != app()->getLocale())
                                <a href="{{ route('lang.switch', $lang) }}">
                                    <img src="{{ asset('photos/' . $lang . '-flag.png') }}" alt="{{ $lang }}" class="langImg">

                                    {{ $details['display'] }}
                                </a>
                                @endif
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>


                <div class="burger-button">
                    <i class="fas fa-bars"></i>
                </div>
            </div>
        </div>
    </div>






















    @foreach($kempings ? [$kempings] : [] as $index => $kemping)

    <div class="centered-box">
        <div class="main">
            <div>
                <B>
                    <P class="bigText">{{ $kemping->majas_nosaukums }}</P>
                </B>
            </div>

            <div class="container">






                <div class="row">
                    <div class="col-8">
                        @php
                        $imageCount = 0;
                        $hasImages = false;
                        for ($x = 0; $x < 15; $x++) { if ($kemping->{'atels' . ($x === 0 ? '' : $x + 1)}) {
                            $hasImages = true;
                            $imageCount++;
                            }
                            }
                            @endphp

                            @if ($hasImages)
                            <div id="carouselExampleIndicators{{ $index }}" class="carousel slide mb-4"
                                data-ride="carousel">
                                <ol class="carousel-indicators">
                                    @for ($i = 0; $i < $imageCount; $i++) <li
                                        data-target="#carouselExampleIndicators{{ $index }}" data-slide-to="{{ $i }}"
                                        class="{{ $i === 0 ? 'active' : '' }}">
                                        </li>
                                        @endfor
                                </ol>

                                <div class="carousel-inner">
                                    @for ($i = 0; $i < $imageCount; $i++) <div
                                        class="carousel-item {{ $i === 0 ? 'active' : '' }}">
                                        <img class="d-block imgCaruseleSizeSetCustom"
                                            src="{{ asset('uploads/kempings/' . $kemping->{'atels' . ($i === 0 ? '' : $i + 1)}) }}"
                                            alt="Image {{ $i + 1 }}">
                                </div>
                                @endfor
                            </div>

                            <a class="carousel-control-prev" href="#carouselExampleIndicators{{ $index }}" role="button"
                                data-slide="prev">
                                <img src="{{ asset('photos/2989989.png') }}" class="imgForCarusel">
                            </a>

                            <a class="carousel-control-next" href="#carouselExampleIndicators{{ $index }}" role="button"
                                data-slide="next">
                                <img src="{{ asset('photos/2989988.png') }}" class="imgForCarusel">
                            </a>
                    </div>
                    @else
                    <p>No images available for carousel</p>
                    @endif
                </div>















                <div class="col-md-4">
    <div class="canendarBox">
        <div class="calendarHeder">
            Pieejamie datumi
        </div>

        <div class="calendar" data-kempings-id="{{ $kemping->id }}" data-booked-dates="{{ json_encode($bookedDates) }}">




            <!-- Calendar content goes here -->
            <div class="month">
                <div class="prev">&#10094;</div>
                <div class="date">
                    <h1 id="calendarHeader"></h1>
                </div>
                <div class="next">&#10095;</div>
            </div>
            <div class="weekdays">
                <div>Sun</div>
                <div>Mon</div>
                <div>Tue</div>
                <div>Wed</div>
                <div>Thu</div>
                <div>Fri</div>
                <div>Sat</div>
            </div>
            <div class="days"></div>
        </div>

        <div class="calanderLine"></div>

        <div class="calendarFooter">
    <a class="calenderButton" data-kempings-id="{{ $kemping->ID }}">Rezervēt</a>
</div>

    </div>
</div>





            </div>
        </div>

        <P class="mt-5">
        <P>{{$kemping->issapraksts}}</P>

        <P>{{$kemping->det_apraksts}}</P>


    </div>
    </div>

    @endforeach







    </div>
    <!-- Stylish Footer -->
    <footer class="footer mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <h3>Contact Us</h3>
                    <p>Email: contact@example.com</p>
                    <p>Phone: +1 (123) 456-7890</p>
                </div>
                <div class="col-md-5">
                    <h3>Follow Us</h3>
                    <div class="social-icons">
                        <!-- Add social media icons or links here -->
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-md-2">
                    <b>© Copyright 2023</b>
                </div>
            </div>
        </div>
    </footer>




<script src="{{ asset('js/advanced.js') }}"></script>
    <script src="index.js"></script>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>

<!-- Inside the <script> tag -->
<script>
$(function() {
    // Initialize selectedDates array
    var selectedDates = [];

    // Function to update selectedDates array when a date is clicked
$(".calendar").on("click", ".days div", function() {
    // Check if the date is max booked
    if ($(this).hasClass("max-booking")) {
        alert("This date is fully booked and cannot be selected.");
        return;
    }

    var day = $(this).text();
    var month = $(".calendar .date h1").text().split(" ")[0];
    var year = $(".calendar .date h1").text().split(" ")[1];

    var date = {
        day: day,
        month: month,
        year: year
    };

    // Toggle class to visually indicate selection
    $(this).toggleClass("selected");

    // Update selectedDates array
    if ($(this).hasClass("selected")) {
        selectedDates.push(date);
    } else {
        var index = selectedDates.findIndex(function(element) {
            return element.day === day && element.month === month && element.year === year;
        });
        if (index !== -1) {
            selectedDates.splice(index, 1);
        }
    }
});
    $(".calenderButton").click(function() {
    var kempingsID = $(this).data("kempings-id");

    // Check if any date is selected
    if (selectedDates.length > 0) {
        // Construct the URL with Kempings ID and selected dates as query parameters
        var url = "/kempings/" + kempingsID + "/rezerv?dates=" + encodeURIComponent(JSON.stringify(selectedDates));

        // Redirect to the reservation page
        window.location.href = url;
    } else {
        alert("Please select at least one date.");
    }
});


    console.log("Script loaded successfully!");
});
</script>






    

</body>

</html>

