<?php

return [
    'kempings' => 'CAMPING',
    'nosvinet' => 'CELEBRATE',
    'makskernieki' => 'FISHERMEN',
    'kontakti' => 'CONTACTS',

    'welcome' => 'About us',

    'welcome2' => 'REST AT BURTNIEKS CAMPING "EZERPRIEDES"',

    'open' => 'We work in the summer season from May 1 to October 31!',

    'message1' => 'Only 130 km from Riga and 28 km from Valmiera in the heart of the Northern Vidzeme Biosphere Reserve
    The "Burtnieks" will present
    To you the power of the waves and the mysterious glow of the sunset. You will enjoy it in the pine grove of the waterfront
    pleasant nature
    mood and peace that can only be felt with us - in Ezerpriedės.',

    'message2' => 'The campsite has a long history, it was created in the 1970s as a recreation base for the Valmiera fire department - now Valpro Corp. But now the 20-season camping is our familys favorite, where we started managing in 2003. The appearance and features of the campsite are slowly changing, the area is being improved and the lakeside is being cleaned, so that you and yours will enjoy relaxing with us!',

    'message3' => 'But the greatest magic is given to this place by the GRAY WIZARD, which is surrounded by tales and legends
    reflected in the clouds.
    In the past, Burtnieks was at least four times larger than it is now and very deep. Unfortunately, the lake
    continues to grow
    and gets shallower and shallower. The ancient Libyans who lived here called Burtnieka Astigjervi
    (in translation it means –
    vessel or Estonian lake) or Asteru.',

    'message4' => 'The legend says that in times when lakes flew through the air, looking for a place for themselves, where Burtnieku
    lake, used to be a church.
    A black cloud has passed over it. Everyone has understood that it is a lake. They told the magician to enchant the lake
    away It said:
    "I dont care." The cloud came to earth because the name of the lake was Burtnieks.',

    'message5' => '
    We are here because our heart, thoughts and future plans belong to this place at Burtnieks! We
        we are happy for yours
        visit and the opportunity to share this natural beauty with you! See you in Ezerpriedes!',

];
