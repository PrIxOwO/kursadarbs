<?php

return [
    'kempings' => 'KEMPINGS',
    'nosvinet' => 'NOSVINĒT',
    'makskernieki' => 'MAKŠĶERNIEKIEM',
    'kontakti' => 'KONTAKTI',

    'welcome' => 'Par mums',

    'welcome2' => 'ATPŪTA PIE SIRMĀ BURTNIEKA KEMPINGĀ „EZERPRIEDES”',

    'open' => 'Mēs strādājam vasaras sezonā no 1. maija līdz 31. oktobrim!',

    'message1' => 'Tikai 130 km no Rīgas un 28 km no Valmieras pašā Ziemeļvidzemes Biosfēras rezervāta sirdī
    Burtnieks dāvās
    Jums savu viļņu spēku un saulrieta noslēpumaino mirdzumu. Krastmalas priežu silā baudīsiet
    patīkamu dabas
    noskaņu un mieru, kādu iespējams sajust tikai pie mums – Ezerpriedēs.',

    'message2' => 'Kempingam ir sena vēsture, tas tapa 1970. gados kā atpūtas bāze Valmieras ugunsdzēsēju rūpnīcai – tagadējais Valpro Corp. Bet nu jau 20. sezonu kempings ir mūsu ģimenes lolojums, kurā sākām saimniekot 2003. gadā. Lēnām mainās kempinga izskats un vaibsti, tiek labiekārtota teritorija un attīrīta ezermala, lai prieks pašiem un arī Jums būtu patīkami pie mums atpūsties!',

    'message3' => 'Taču pašu lielāko burvību šai vietai piešķir SIRMAIS BURTNIEKS, kas teiku un leģendu apvīts
    spoguļojas mākoņos.
    Agrāk Burtnieks bijis vismaz četras reizes lielāks nekā tagad un ļoti dziļš. Diemžēl ezers
    arvien turpina aizaugt
    un kļūst arvien seklāks. Senie lībieši, kas te dzīvojuši, saukuši Burtnieku par Astigjervi
    (tulkojumā tas nozīmē –
    trauks vai Igauņu ezers) vai Asteru.',

    'message4' => 'Teika vēsta, ka laikos, kad ezeri lidojuši pa gaisu, sev vietu meklēdami, tur, kur Burtnieku
    ezers, bijusi baznīca.
    Pār to laidies melns mākonis. Visi sapratuši, ka tas ezers. Teikuši burvim, lai aizbur ezeru
    prom. Tas teicis:
    «Man burt nieks.» Mākonis nonācis zemē, jo ezera vārds bijis Burtnieks.',

    'message5' => 'Mēs esam šeit, jo šai vietai pie Burtnieka pieder mūsu sirds, domas un nākotnes ieceres! Mēs
    priecājamies par Jūsu
    ciemošanos un iespēju dalīties šajā dabas skaistumā ar Jums! Uz tikšanos Ezerpriedēs!',

];
