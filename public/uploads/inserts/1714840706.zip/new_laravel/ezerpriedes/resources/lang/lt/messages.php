<?php
return [
    'kempings' => 'KEMPINGAS',
    'nosvinet' => 'ŠVESTI',
    'makskernieki' => 'MAKSHKERNIEKIUI',
    'kontakti' => 'KONTAKTAI',

    'welcome' => 'Apie mus',

    'welcome2' => 'POILSIS BURTNIEKO KEMPINGE „EZERPRIEDES“',

    'open' => 'Dirbame vasaros sezonu nuo gegužės 1 iki spalio 31 dienos!',

    'message1' => 'Tik 130 km nuo Rygos ir 28 km nuo Valmieros, Šiaurės Vidžemės biosferos rezervato širdyje
    Rašytojas pristatys
    Tau bangų galia ir paslaptingas saulėlydžio švytėjimas. Mėgausitės pakrantės pušyne
    maloni gamta
    nuotaika ir ramybė, kurią galima pajusti tik pas mus - Ezerpriedėse.',

    'message2' => 'Stovyklavietė turi ilgą istoriją, ji buvo sukurta 1970-aisiais kaip Valmieros ugniagesių - dabar Valpro Corp - poilsio bazė. Tačiau dabar 20 sezonų kempingas yra mūsų šeimos mėgstamiausias, kuriame pradėjome vadovauti 2003 m. Po truputį keičiasi kempingo išvaizda ir ypatumai, tobulinama teritorija, valomas paežerys, kad ir Jums, ir Jūsų mėgautųsi poilsis pas mus!',

    'message3' => 'Tačiau didžiausią magiją šiai vietai suteikia pasakų ir legendų apipintas PILKAS VEDLIKAS
    atsispindi debesyse.
    Anksčiau Burtnieks buvo bent keturis kartus didesnis nei dabar ir labai gilus. Deja, ežeras
    toliau auga
    ir darosi vis sekliau. Čia gyvenę senovės libiečiai vadino Burtnieka Astigjervi
    (išvertus tai reiškia –
    laivas arba Estijos ežeras) arba Asteru.',

    'message4' => 'Legenda pasakoja, kad tais laikais, kai ežerai skraidė oru, ieškodami sau vietos, kur Burtnieku
    ežeras, anksčiau buvo bažnyčia.
    Juodasis debesis praslinko. Visi suprato, kad tai ežeras. Jie liepė burtininkui užburti ežerą
    toli Jame buvo parašyta:
    — Man nesvarbu. Debesis atėjo į žemę, nes ežero pavadinimas buvo Burtnieks.',

    'message5' => 'Esame čia, nes mūsų širdis, mintys ir ateities planai priklauso šiai Burtniekso vietai! Mes
    džiaugiamės už jus
    apsilankymas ir galimybė su jumis pasidalinti šiuo gamtos grožiu! Iki pasimatymo Ezerpriedėse!',

];