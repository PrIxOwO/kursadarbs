<?php
return [
    'kempings' => 'CAMPING',
    'nosvinet' => 'FEIERN',
    'makskernieki' => 'MASKHERNIKER',
    'kontakti' => 'KONTAKTE',


    'welcome' => 'Über uns',

    'welcome2' => 'RUHE AUF BURTNIEKS CAMPING „EZERPRIEDES“"',

    'open' => 'Wir arbeiten in der Sommersaison vom 1. Mai bis 31. Oktober!',

    'message1' => 'Nur 130 km von Riga und 28 km von Valmiera entfernt, im Herzen des Biosphärenreservats Nördliches Vidzeme
    Der Rechtschreibprüfer wird angezeigt
    Für Sie die Kraft der Wellen und das geheimnisvolle Leuchten des Sonnenuntergangs. Sie werden es im Pinienhain am Wasser genießen
    angenehme Natur
    Stimmung und Frieden, die man nur bei uns spüren kann – in Ezerpriedės.',

    'message2' => 'Der Campingplatz hat eine lange Geschichte, er wurde in den 1970er Jahren als Erholungsbasis für die Feuerwehr Valmiera – jetzt Valpro Corp. – gegründet. Aber jetzt ist der 20-Saison-Campingplatz der Liebling unserer Familie, den wir 2003 zu verwalten begonnen haben. Das Aussehen und die Merkmale des Campingplatzes verändern sich langsam, das Gelände wird verbessert und der Uferbereich wird gereinigt, damit Sie und Ihre Familie sich bei uns entspannen können!',

    'message3' => 'Die größte Magie verleiht diesem Ort jedoch der GRAUE ZAUBERER, der von Geschichten und Legenden umgeben ist
    spiegelt sich in den Wolken.
    In der Vergangenheit war Burtnieks mindestens viermal größer als heute und sehr tief. Leider der See
    es wächst weiter
    und wird immer flacher. Die alten Libyer, die hier lebten, nannten Burtnieka Astigjervi
    (in der Übersetzung bedeutet es –
    Schiff oder estnischer See) oder Asteru.',

    'message4' => 'Die Legende besagt, dass in Zeiten, als Seen durch die Luft flogen und einen Ort für sich suchten, Burtnieku
    See, war früher eine Kirche.
    Eine schwarze Wolke ist darüber hinweggezogen. Jeder hat verstanden, dass es ein See ist. Sie sagten dem Zauberer, er solle den See verzaubern
    weg Es sagte:
    "Es ist mir egal." Die Wolke kam auf die Erde, weil der See Burtnieks hieß.',

    'message5' => 'Wir sind hier, weil unser Herz, unsere Gedanken und unsere Zukunftspläne diesem Ort bei Burtnieks gehören! Wir
    Wir freuen uns für Sie
    Besuch und die Gelegenheit, diese natürliche Schönheit mit Ihnen zu teilen! Wir sehen uns in Ezerpriedes!',

];