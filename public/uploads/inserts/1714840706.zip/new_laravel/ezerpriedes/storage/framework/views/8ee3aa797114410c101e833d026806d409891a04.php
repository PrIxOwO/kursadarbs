<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

        <?php echo $__env->yieldContent('content'); ?>
<?php /**PATH C:\Users\klavs\OneDrive\Desktop\new_laravel\ezerpriedes\resources\views/layouts/app.blade.php ENDPATH**/ ?>