

<?php $__env->startSection('content'); ?>
    <h1><?php echo e(__('languageDemo.welcome')); ?></h1>
    <p><?php echo e(__('languageDemo.introduction')); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\klavs\OneDrive\Desktop\new_laravel\ezerpriedes\resources\views/languageDemo.blade.php ENDPATH**/ ?>