<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reservation</title>
    <!-- Add your CSS links here -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <!-- Add the Font Awesome link here -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/heder.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <!-- Add the Font Awesome link here -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/heder.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/kenpings.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/calendar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/homes.css')); ?>">
    <link rel="stylesheet" href="css/heder.css">
    <style>
        /* Your custom CSS styles */
        .calendar {
            max-width: 400px;
            margin: 0 auto;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-family: Arial, sans-serif;
        }

        .calendar-header {
            background-color: #f9a346;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
        }

        .calendar-body {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            border-bottom: 1px solid #ccc;
        }

        .calendar-day {
            padding: 10px;
            text-align: center;
            border-right: 1px solid #ccc;
            border-bottom: 1px solid #ccc;
            cursor: pointer;
        }

        .calendar-day:last-child {
            border-right: none;
        }

        .calendar-day:hover {
            background-color: #f0f0f0;
        }

        .selected {
            background-color: #e26143;
        }

        .prev,
        .next {
            cursor: pointer;
        }

        .weekdays {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            border-bottom: 1px solid #ccc;
            font-weight: bold;
            text-align: center;
        }

        .weekdays div {
            padding: 10px 0;
        }

        *{
    text-decoration: none !important ;
}
    </style>
</head>
<body>
<div class="header">
        <div class="positionHederMain">
            <div class="container-fluid d-flex align-items-center justify-content-between">

                <!-- Move NOSVINĒT to the left side -->
                <div class="header-text">
                    <a href="/" class="homePageFont thisPageID">EZERPRIEDES</a>
                    <a href="/kempings"><?php echo e(__('messages.kempings')); ?></a>
                    <a href="/nosvinet"><?php echo e(__('messages.nosvinet')); ?></a>

                    <a href="/makskerniekiem"><?php echo e(__('messages.makskernieki')); ?></a>

                </div>

                <div class="d-flex">
                    
                    <div class="dropdown dropdownMenuMarginNavBar">
                        <div class="dropdown">
                            <button class="dropbtn">
                                <div class="language-button">
                                    <div class="d-flex align-items-center justify-content-center">
                                        <div class="ml-4">
                                            <img src="<?php echo e(asset('photos/' . app()->getLocale() . '-flag.png')); ?>" alt="<?php echo e(app()->getLocale()); ?>" class="langImg worldMarginIcon">

                                        </div>
                                        <div class="mr-2 alineFlagToName">

                                            <?php $__currentLoopData = config('languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($lang == app()->getLocale()): ?>
                                            <?php echo e($details['display']); ?>

                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div>
                                            <img src="<?php echo e(asset('photos/down-arrow.png')); ?>" alt="headerPhoto" class="langImg">

                                        </div>
                                    </div>
                                </div>
                            </button>
                            <div id="myDropdown" class="dropdown-content">
                                <?php $__currentLoopData = config('languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($lang != app()->getLocale()): ?>
                                <a href="<?php echo e(route('lang.switch', $lang)); ?>">
                                    <img src="<?php echo e(asset('photos/' . $lang . '-flag.png')); ?>" alt="<?php echo e($lang); ?>" class="langImg">

                                    <?php echo e($details['display']); ?>

                                </a>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="burger-button">
                    <i class="fas fa-bars"></i>
                </div>
            </div>
        </div>
    </div>



    <!-- Your header content goes here -->

    <h1><?php echo e($kemping->majas_nosaukums); ?></h1>

    <!-- Calendar container -->
    <div class="calendar">
        <div class="calendar-header">
            <!-- Add navigation buttons for previous and next month -->
            <!--<button class="prev">&#10094;</button>-->
            <h1 id="calendar-header"></h1>
            <!--<button class="next">&#10095;</button>-->
        </div>
        <div class="weekdays">
            <div>Sun</div>
            <div>Mon</div>
            <div>Tue</div>
            <div>Wed</div>
            <div>Thu</div>
            <div>Fri</div>
            <div>Sat</div>
        </div>
        <div class="calendar-body" id="calendar-body">
            <!-- Calendar days will be rendered here -->
        </div>
    </div>

    <!-- Selected dates section -->
    <h2>Selected Dates:</h2>
    <ul id="selected-dates">
        <!-- Selected dates will be rendered here -->
    </ul>

    <!-- Your footer content goes here -->

    <!-- Add your JavaScript code -->
    <script>
// Define selectedDates array
let selectedDates = [];
const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

// Parse URL parameters
const urlParams = new URLSearchParams(window.location.search);

// Event listener for page load and browser back button
document.addEventListener('DOMContentLoaded', () => {
    loadCalendar();
});

window.addEventListener('popstate', () => {
    // Reload the page when navigating back to ensure the JavaScript code runs
    location.reload();
});

// Function to load calendar
function loadCalendar() {
    // Extract selected dates from URL query parameter
    const datesParam = urlParams.get('dates');
    if (datesParam) {
        const parsedDates = JSON.parse(datesParam);
        // Convert each parsed date into a Date object
        selectedDates = parsedDates.map(date => new Date(date.year, getMonthNumber(date.month), date.day));
    }

    // Extract month and year from URL query parameter
    const monthParam = urlParams.get('month');
    const yearParam = urlParams.get('year');
    let currentDate;
    if (monthParam !== null && yearParam !== null) {
        // If both month and year are provided, render calendar based on these values
        currentDate = new Date(parseInt(yearParam), getMonthNumber(monthParam));
    } else {
        // Otherwise, default to the first date in selectedDates array or current month
        currentDate = selectedDates.length > 0 ? selectedDates[0] : new Date();
    }

    // Render calendar
    renderCalendar(currentDate);
}

// Rest of your code...



// Rest of your code...

// Function to update selected dates UI
function updateSelectedDates() {
    const selectedDatesList = document.getElementById('selected-dates');
    selectedDatesList.innerHTML = '';
    selectedDates.forEach(date => {
        const listItem = document.createElement('li');
        listItem.textContent = formatDate(date);
        selectedDatesList.appendChild(listItem);
    });
}

// Function to render the calendar
function renderCalendar(date) {
    const calendarHeader = document.getElementById('calendar-header');
    const calendarBody = document.getElementById('calendar-body');

    // Set calendar header
    calendarHeader.textContent = date.toLocaleString('default', { month: 'long', year: 'numeric' });

    // Clear calendar body
    calendarBody.innerHTML = '';

    // Get the first day of the month
    const firstDay = new Date(date.getFullYear(), date.getMonth(), 1);

    // Get the last day of the month
    const lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);

    // Get the number of days in the month
    const numDays = lastDay.getDate();

    // Get the day of the week for the first day of the month (0 for Sunday, 1 for Monday, etc.)
    const startDayOfWeek = firstDay.getDay();

    // Fill in the calendar grid with days of the month
    for (let i = 1; i <= numDays; i++) {
        const day = document.createElement('div');
        day.classList.add('calendar-day');
        day.textContent = i;

        // Check if the current date is in the selectedDates array
        const currentDate = new Date(date.getFullYear(), date.getMonth(), i);
        if (selectedDates.find(date => date.getTime() === currentDate.getTime())) {
            day.classList.add('selected');
        }

        calendarBody.appendChild(day);
    }

    // Update selected dates UI
    updateSelectedDates();

    // Store selected dates in sessionStorage
    sessionStorage.setItem('selectedDates', JSON.stringify(selectedDates));
}

// Function to get month number from month name
function getMonthNumber(monthName) {
    return monthNames.indexOf(monthName);
}

// Format date as 'YYYY-MM-DD'
function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// Event listener for navigation buttons
document.addEventListener('click', event => {
    if (event.target.classList.contains('prev') || event.target.classList.contains('next')) {
        // Clear selected dates when navigating away
        sessionStorage.removeItem('selectedDates');
    }
    // Your existing navigation logic...
});

    </script>
<script src="js/index.js"></script>
</body>
</html>
<?php /**PATH C:\Users\klavs\OneDrive\Desktop\new_laravel\ezerpriedes\resources\views/rezerv.blade.php ENDPATH**/ ?>