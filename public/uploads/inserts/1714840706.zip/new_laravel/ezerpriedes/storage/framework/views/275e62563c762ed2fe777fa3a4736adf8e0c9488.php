<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Ezerpriedes</title>
    <!-- Add the Bootstrap CSS link here -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <!-- Add the Font Awesome link here -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/heder.css">
    <link rel="stylesheet" href="css/kenpings.css">
    
    <style>
        .containerOwerider {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            /* Add gap between cards */
        }

        .owerlapToFullDisplay2 {
            flex: 0 0 calc(33.333% - 20px);
            /* Adjust width and gap based on your design */
            box-sizing: border-box;
        }

        @media (max-width: 992px) {
            .owerlapToFullDisplay2 {
                flex: 0 0 calc(50% - 20px);
            }
        }

        @media (max-width: 768px) {
            .owerlapToFullDisplay2 {
                flex: 0 0 calc(50% - 20px);
            }
        }

    </style>
</head>

<body>

<div class="header">
        <div class="positionHederMain">
            <div class="container-fluid d-flex align-items-center justify-content-between">

                <!-- Move NOSVINĒT to the left side -->
                <div class="header-text">
                    <a href="/" class="homePageFont thisPageID">EZERPRIEDES</a>
                    <a href="/kempings"><?php echo e(__('messages.kempings')); ?></a>
                    <a href="/nosvinet"><?php echo e(__('messages.nosvinet')); ?></a>

                    <a href="/makskerniekiem"><?php echo e(__('messages.makskernieki')); ?></a>

                </div>

                <div class="d-flex">
                    <a href="#" id="kontakti-link"><?php echo e(__('messages.kontakti')); ?></a>
                    <div class="dropdown dropdownMenuMarginNavBar">
                        <div class="dropdown">
                            <button class="dropbtn">
                                <div class="language-button">
                                    <div class="d-flex align-items-center justify-content-center">
                                        <div class="ml-4">
                                            <img src="photos/<?php echo e(app()->getLocale()); ?>-flag.png" alt="<?php echo e(app()->getLocale()); ?>" class="langImg worldMarginIcon">
                                        </div>
                                        <div class="mr-2 alineFlagToName">

                                            <?php $__currentLoopData = config('languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($lang == app()->getLocale()): ?>
                                            <?php echo e($details['display']); ?>

                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <div>
                                            <img src="photos/down-arrow.png" alt="headerPhoto" class="langImg">
                                        </div>
                                    </div>
                                </div>
                            </button>
                            <div id="myDropdown" class="dropdown-content">
                                <?php $__currentLoopData = config('languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($lang != app()->getLocale()): ?>
                                <a href="<?php echo e(route('lang.switch', $lang)); ?>">
                                    <img src="photos/<?php echo e($lang); ?>-flag.png" alt="<?php echo e($lang); ?>" class="langImg">
                                    <?php echo e($details['display']); ?>

                                </a>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="burger-button">
                    <i class="fas fa-bars"></i>
                </div>
            </div>
        </div>
    </div>







    <div class="popup" id="popup1">
        <div class="popupuBorderIner">
            <div class="d-flex justify-content-start">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone phoneAligne" viewBox="0 0 16 16">
                    <path d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.6 17.6 0 0 0 4.168 6.608 17.6 17.6 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.68.68 0 0 0-.58-.122l-2.19.547a1.75 1.75 0 0 1-1.657-.459L5.482 8.062a1.75 1.75 0 0 1-.46-1.657l.548-2.19a.68.68 0 0 0-.122-.58zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.68.68 0 0 0 .178.643l2.457 2.457a.68.68 0 0 0 .644.178l2.189-.547a1.75 1.75 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.6 18.6 0 0 1-7.01-4.42 18.6 18.6 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877z" />
                </svg>
                <p> +371 29461455</p>
            </div>
            <div class="d-flex justify-content-start">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope phoneAligne" viewBox="0 0 16 16">
                    <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1zm13 2.383-4.708 2.825L15 11.105zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741M1 11.105l4.708-2.897L1 5.383z" />
                </svg>
                <p> info@ezerpriedes.lv</p>
            </div>
        </div>
        <a href="#" onclick="hide('popup1')">Ok!</a>
    </div>

















    <div class="centered-box">

        <div class="main">
            <p><b>Kempinga mājiņas pieejamas no 1. maija līdz 31.oktobrim!</b></p>


            <!-- ... your existing content ... -->

            <div class="container containerOwerider">
                <div class="row">

                    <div class="col-lg-7 col-md-12">
                        <div class="d-flex justify-content-between flex-wrap">
                            <?php $__currentLoopData = $kempings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kemping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="owerlapToFullDisplay2 mx-auto mb-4">
                                <a href="<?php echo e(url('/kempings/' . $kemping->ID)); ?>" class="cardButton">


                                    <div class="card">
                                        <?php if($kemping->atels): ?>
                                        <img src="<?php echo e(asset('uploads\kempings/' . $kemping->atels)); ?>" class="img">
                                        <?php else: ?>
                                        <p>No image available !!!</p>
                                        <?php endif; ?>
                                        <div class="container">
                                            <h4 class="cardText"><b><?php echo e($kemping->majas_nosaukums); ?></b></h4>
                                            <span class="cardPrice">€ <?php echo e($kemping->price); ?>+</span>
                                            <div class="cardDevidingLine"></div>
                                            <p><?php echo e($kemping->issapraksts); ?></p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- apraksta daļā -->
                    <div class="col-lg-5 col-md-12 marginTopSmallDisplay">
                        <p>Kempinga mājiņa ir Jūsu rīcībā no 14:00 ierašanās dienā līdz 12:00 izbraukšanas dienā, ja nav
                            citas vienošanas ar kempinga administratoru.</p>

                        <div class="textDeviderLines"></div>

                        <p>Mēs piedāvājam 10 dažāda veida un komforta līmeņa kempinga mājiņas, kopā nodrošinot 40
                            gultasvietas. Pieejamas līdz 10 treileru vietas ar elektrības pieslēgumu. Telts vietas –
                            neierobežotā skaitā.</p>

                        <div class="textDeviderLines"></div>

                        <p>Esam mājdzīvniekiem draudzīgs kempings un gaidām Jūs ciemos ar četrkājaino draugu! Maksa par
                            mājdzīvnieka uzturēšanos kempingā ir 5 Eur uz visu nakšņošanas laiku!</p>

                        <div class="textDeviderLines"></div>

                        <p>Bērniem līdz 6 gadu vecumam nakšņošana kempingā bez maksas. No 7 – 12 gadu vecumam 50 %
                            atlaide.</p>

                        <div class="textDeviderLines"></div>

                        <p>Lūdzu ņemt vērā! Viesiem ierašanās kempinga mājiņās līdz plkst. 18.00. Par kavēšanos lūdzu
                            informēt pa tālr. 29461455, pretējā gadījumā kempinga mājiņas rezervācija tiks atcelta.</p>






                    </div>

                </div>
            </div>



        </div>
    </div>
    <!-- Stylish Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <h3>Contact Us</h3>
                    <p>Email: contact@example.com</p>
                    <p>Phone: +1 (123) 456-7890</p>
                </div>
                <div class="col-md-5">
                    <h3>Follow Us</h3>
                    <div class="social-icons">
                        <!-- Add social media icons or links here -->
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-md-2">
                    <b>© Copyright 2023</b>
                </div>
            </div>
        </div>
    </footer>

    <script src="js/index.js"></script>
    <script src="index.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha256-SkW4XZBjG0rTY3ngdW3Ed4NxqmGXvACb43G+a+ARrVo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MC9zTCdW04XsK3Tx2Xt5f6KG4sI72GY9n0BzmXnP2X2PeM/MAaHMN7FCfDIlvvn"
        crossorigin="anonymous"></script>


</body>

</html><?php /**PATH C:\Users\klavs\OneDrive\Desktop\new_laravel\ezerpriedes\resources\views/kempings.blade.php ENDPATH**/ ?>