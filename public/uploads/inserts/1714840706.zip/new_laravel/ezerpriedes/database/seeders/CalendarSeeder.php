<?php

namespace Database\Seeders;
use Illuminate\Support\Facades\DB;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CalendarSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('calendars')->insert([
            'date' => '2024-02-10',
            'max' => 1,
            'mid' => 1,
            'low' => 0,
            'kempings_id' => 1,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}
