<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('kempings', function (Blueprint $table) {
            $table->ID();
            $table->string('atels')->nullable();
            $table->string('atels2')->nullable();
            $table->string('atels3')->nullable();
            $table->string('atels4')->nullable();
            $table->string('atels5');
            $table->string('atels6');
            $table->string('atels7');
            $table->string('atels8');
            $table->string('atels9');
            $table->string('atels10');
            $table->string('atels11');
            $table->string('atels12');
            $table->string('atels13');
            $table->string('atels14');
            $table->text("det_apraksts")->nullable();
            $table->string("issaprksts");
            $table->string("majas_nosaukums");
            $table->integer("price");
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('kempings');
    }
};
